from controller import Robot

def run_robot():

    robot = Robot()

    timestep = int(robot.getBasicTimeStep())

    motor1 = robot.getDevice('motor')

    motor1.setPosition(float('inf'))
    motor1.setVelocity(2.0)

    while robot.step(timestep) != -1:
        pass

if __name__ == "__main__":
    run_robot()